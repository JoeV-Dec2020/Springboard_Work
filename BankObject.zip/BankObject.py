import os
import sys
from datetime import datetime

BASE_DIR = os.path.split(__file__)[0]

class BankObject():
    """ Base class for entire module identifying variables and
    functions.
    """
    _MENU_TITLE = '' # Title Display Name set for each Object Type
    _MENU_OPTIONS = [] # List of options for each Object Type
    _MENU_ACTIONS = [] # List of Action IDs for each Object Type
    _MENU_LENGTH = 0 # Number of Menu Options for each Object Type
    _DATA_FILE = '' # Full directory path to Object Type data file
    _DATA_FLDS = [] # List of Data Fields for each Object Type 
    _DATA_STOR = [] # _DATA_STOR field layout: [<Object ID>,<Parent ID>,
                    # <Active (TRUE/FALSE)>,<Data Fields,...>]

    def __init__(self):
        """Basic initializer"""
        pass

    def get_ret_value(self, max_value):
        """ Requests user to enter a desired menu or option number,
        confirms entry validity, and returns the entered value.
        """
        ret_value = '' # initialize to null value to identify input
        while (not ret_value.isnumeric() or
               not (1 <= int(ret_value) <= max_value)):
            print('')
            if ret_value != '': # check if a value has been entered ...
                print('You entered an invalid option!')
            ret_value = input('Please select the desired ' + self._MENU_TITLE
                              + ' Menu option: ')

        return ret_value

    def get_menu_opt(self):
        """ Displays current menu options, calls get_ret_value to
        receive user's entry, and returns requested action value to
        caller.
        """
        print('\n' + self._MENU_TITLE + ' Menu\n')
        for menu_opt in range(0, self._MENU_LENGTH): # display options
            print(str(menu_opt + 1) + '. ' + self._MENU_OPTIONS[menu_opt])

        self.write_log('Calling get_ret_value function',False)
        ret_value = self.get_ret_value(self._MENU_LENGTH) # get choice
        self.write_log('Returned from get_ret_value function',False)
        return (self._MENU_ACTIONS[int(ret_value) - 1]) # return choice

    def read_data(self, parent_id = 'Null'):
        """ Attempts to open the appropriate data file, reads contents
        into the data store, and closes the file.
        """
        return_cnt = 0 # initialize _DATA_STOR record count to zero
        self._DATA_STOR = [] # initialize _DATA_STOR to empty
        if not os.path.exists(self._DATA_FILE): # if data file missing
            self.write_log('Data file DOES NOT EXIST!', True) # print
        else:
            read_file = open(self._DATA_FILE, 'r')
            for read_line in read_file: # read each line, keep desired
                read_line = read_line.strip("['")
                read_line = read_line.strip("']\n")
                read_rec = list(read_line.split("', '"))
                if read_rec[2] == 'True' and read_rec[1] == parent_id:
                    return_cnt += 1
                self._DATA_STOR.append(list(read_line.split("', '")))
            read_file.close() # close file after all lines read
        return return_cnt # return count of active/appropriate records

    def save_data(self):
        """ Attempts to open the appropriate data file, writes contents
        of the modified _DATA_STOR into the file, and closes the file.
        """
        return_size = 0 
        write_file = open(self._DATA_FILE, 'w') # open object data file
        for data_record in self._DATA_STOR: # write each list element
            return_size += write_file.write(str(data_record) + '\n')
        write_file.close() # close object data file

        return return_size # return size of data written to file

    def get_next_id(self):
        """ Attempts to open the appropriate data file, reads contents
        of data store identifying the maximum ID, closes the file, and
        returns the maximum value found + 1.
        """
        MAX_ID = 0 # sets initial MAX_ID value for counting
        if not os.path.exists(self._DATA_FILE): # Missing file error
            self.write_log('Data file DOES NOT EXIST!', True) # print
        else:
            read_file = open(self._DATA_FILE, 'r') # open data file
            for read_line in read_file: # read each line, update MAX_ID
                read_line = read_line.strip("['")
                read_line = read_line.strip("']\n")
                read_line = list(read_line.split("', '"))
                if int(read_line[0]) > MAX_ID:
                    MAX_ID = int(read_line[0])
            read_file.close() # close data file
        MAX_ID = MAX_ID + 1 # increment MAX_ID for next record
        return MAX_ID

    def write_log(self, log_msg, print_msg):
        """Receives log_msg from function call, and appends it to the end of
        the LOG_FILE - if the print_msg value is True, message also printed
        to stdout.
        """
        LOG_FILE = BASE_DIR + '/log/bank_system.log' # set LOG_FILE path
        log_text = (str(datetime.now()) + ' - ' + self._MENU_TITLE +
                    ' - ' + log_msg) # format log_text for output
        write_file = open(LOG_FILE, 'a') # open log file for appending
        return_size = write_file.write(log_text + '\n') # print message
        write_file.close() # close log file

        if print_msg: # if print_msg is True, print message to stdout
            print(log_msg + '\n')

        return return_size # return size of data printed to log

    def view_object(self, parent_id = 'Null'):
        """Display all records of the current object type, call
        get_ret_value to identify which record to display, and
        print each data field with its specific value.
        """
        self.write_log('Calling read_data function',False)
        if self.read_data(parent_id) > 0: # call read_data for records
            self.write_log('Returned from read_data function',False)
            print('The ' + self._MENU_TITLE + 's to select from:\n')
            view_row = 0 # initialize row number before displaying any
            for view_line in self._DATA_STOR: # loop through _DATA_STOR
                if view_line[2] == 'True' and view_line[1] == parent_id:
                    view_row += 1 # show active/appropriate reocrds
                    print(str(view_row) + '. ' + str(view_line[3:]))

            self.write_log('Calling get_ret_value function',False)
            view_index = self.get_ret_value(view_row) # user selects rec
            self.write_log('Returned from get_ret_value function',False)
            find_rec = 0 # index used to identify active/appropirate rec
            for view_rec in self._DATA_STOR:
                if view_rec[2] == 'True' and view_rec[1] == parent_id:
                    find_rec += 1
                if find_rec == int(view_index): # break if desired rec
                    break

            print('')
            field_index = 0 # index used to display only data fields
            for field_name in self._DATA_FLDS:
                print(field_name + ': ' + view_rec[field_index + 3])
                field_index += 1
        else:
            self.write_log('No data to select from!',True) # print msgs
        return

    def add_object(self, parent_id = 'Null'):
        """Create a new list record cycling through the list of field
        names for user input, and append it into the appropriate object
        data file.
        """
        new_record = []
        new_record.append(str(self.get_next_id()))
        new_record.append(parent_id)
        new_record.append('True')

        for field_name in self._DATA_FLDS: # cycle through object fields
            new_record.append(input('Please input ' + field_name + ': '))
        write_file = open(self._DATA_FILE, 'a') # append to data file
        return_size = write_file.write(str(new_record) + '\n')
        write_file.close() # close data file
        return return_size # return size of data appended

    def mod_object(self, parent_id = 'Null'):
        """Display all records of the current object type, call
        get_ret_value to identify which record to modify, and
        cycle through each field having user update or hit <enter>
        to keep the original value.
        """
        self.write_log('Calling read_data function',False)
        if self.read_data(parent_id) > 0: # call read_data for records
            self.write_log('Returned from read_data function',False)
            print('The ' + self._MENU_TITLE + 's to select to modify:\n')
            view_row = 0 # initialize row number before displaying any
            for view_line in self._DATA_STOR: # loop through _DATA_STOR
                if view_line[2] == 'True' and view_line[1] == parent_id:
                    view_row += 1 # show active/appropriate reocrds
                    print(str(view_row) + '. ' + str(view_line[3:]))

            self.write_log('Calling get_ret_value function',False)
            mod_index = self.get_ret_value(view_row)
            self.write_log('Returned from get_ret_value function',False)
            rec_index = 0 # index used to identify record in entire list
            find_rec  = 0 # index to identify active/appropirate rec
            for view_rec in self._DATA_STOR: # identify list index
                if view_rec[2] == 'True' and view_rec[1] == parent_id:
                    find_rec += 1
                if find_rec == int(mod_index):
                    break
                rec_index += 1

            print('\nFollowing is the list of current field values - enter '
                  + 'a new value or hit <ENTER> to keep the old value: ')
            field_num = 3 # index with offset to update only data fields
            for field_name in self._DATA_FLDS:
                update_val = '' #cycle through fields to update or keep
                update_val =input(field_name + ' - '
                                  + self._DATA_STOR[rec_index][field_num]
                                  + ': ')
                if update_val != '': # if field modified, update
                    self._DATA_STOR[rec_index][field_num] = update_val
                field_num += 1

            self.write_log('Calling save_data function',False)
            save_val = self.save_data() # save the updated _DATA_STOR
            self.write_log('Returned from save_data function',False)
        else:
            self.write_log('No data to select from!',True) # print msgs
        return

    def del_object(self, parent_id = 'Null'):
        """Display all records of the current object type, call
        get_ret_value to identify which record to delete, and
        update the desired record to set the active identifier
        (record[2]) to False.
        """
        self.write_log('Calling read_data function',False)
        if self.read_data(parent_id) > 0:
            self.write_log('Returned from read_data function',False)
            print('The ' + self._MENU_TITLE + 's to select to delete:\n')
            view_row = 0 # initialize row number before displaying any
            for view_line in self._DATA_STOR: # loop through _DATA_STOR
                if view_line[2] == 'True' and view_line[1] == parent_id:
                    view_row += 1 # show active/appropriate reocrds
                    print(str(view_row) + '. ' + str(view_line[3:]))

            self.write_log('Calling get_ret_value function',False)
            del_index = self.get_ret_value(view_row)
            self.write_log('Returned from get_ret_value function',False)
            rec_index = 0 # index used to identify record in entire list
            find_rec  = 0 # index to identify active/appropirate recs
            for view_rec in self._DATA_STOR: # identify list index
                if view_rec[2] == 'True' and view_rec[1] == parent_id:
                    find_rec += 1
                if find_rec == int(del_index):
                    break # if record to delete is found, break
                rec_index += 1

            self._DATA_STOR[rec_index][2] = 'False' # set rec inactive
            self.write_log('Calling save_data function',False)
            save_val = self.save_data() # save the updated _DATA_STOR
            self.write_log('Returned from save_data function',False)
        else:
            self.write_log('No data to select from!',True) # print msgs
        return


class MainMenu(BankObject):
    """ Main Menu class that inherits from the Bank Object class to
    process top main menu.
    """
    _MENU_TITLE = 'Main'
    _MENU_OPTIONS = ['Customer','Employee','Account','Exit']
    _MENU_ACTIONS = [11,12,13,999]
    _MENU_LENGTH = len(_MENU_OPTIONS)


class Customer(BankObject):
    """ Customer class that inherits from the Bank Object class to
    process customer functionality.
    """
    _MENU_TITLE = 'Customer'
    _MENU_OPTIONS = ['View Customer','Add Customer','Modify Customer',
                     'Delete Customer','Main Menu','Exit']
    _MENU_ACTIONS = [111,112,113,114,1,999]
    _MENU_LENGTH = len(_MENU_OPTIONS)
    _DATA_FILE = BASE_DIR + '/data/cust_info.dat'
    _DATA_FLDS = ['Custommer First Name','Customer Last Name',
                  'Customer Address','Customer Phone',
                  'Customer Birthdate','Customer Status']


class Employee(BankObject):
    """ Employee class that inherits from the Bank Object class to
    process employee functionality.
    """
    _MENU_TITLE = 'Employee'
    _MENU_OPTIONS = ['View Employee','Add Employee','Modify Employee',
                     'Delete Employee','Main Menu','Exit']
    _MENU_ACTIONS = [121,122,123,124,1,999]
    _MENU_LENGTH = len(_MENU_OPTIONS)
    _DATA_FILE = BASE_DIR + '/data/emp_info.dat'
    _DATA_FLDS = ['Employee First Name','Employee Last Name',
                  'Employee Position','Employee Hire Date',
                  'Employee Status']


class Account(BankObject):
    """ Account class that inherits from the Bank Object class, and adds
    the sel_cust_id function to identify the customer to limit accounts,
    to process account functionality.
    """
    _MENU_TITLE = 'Account'
    _MENU_OPTIONS = ['View Account','Add Account','Modify Account',
                     'Delete Account','Main Menu','Exit']
    _MENU_ACTIONS = [131,132,133,134,1,999]
    _MENU_LENGTH = len(_MENU_OPTIONS)
    _DATA_FILE = BASE_DIR + '/data/acct_info.dat'
    _DATA_FLDS = ['Account Number','Account Type','Account Balance',
                  'Account Status']

    def sel_cust_id(self):
        """ Attempts to open the customer data file, reads contents and
        supplies list of active customers for the user to select the
        customer to get a list of active accounts, and closes the file.
        """
        cust_id = '' # set return cust_id to NULL
        tmp_cust_obj = Customer() # create temporary Customer Object
        if tmp_cust_obj.read_data() > 0: # where there is Customer Data
            print('Please select a ' + tmp_cust_obj._MENU_TITLE
                  + 's to select from:\n')
            view_row = 0 # index to display Active Customers
            for view_line in tmp_cust_obj._DATA_STOR:
                if view_line[2] == 'True': # current Customer is Active
                    view_row += 1 # Customer index incrementation
                    print(str(view_row) + '. ' + str(view_line[3:]))

            self.write_log('Calling get_ret_value function',False)
            view_index = self.get_ret_value(view_row) # user selection
            self.write_log('Returned from get_ret_value function',False)
            find_rec = 0 # additional index to identify Customer ID
            for view_rec in tmp_cust_obj._DATA_STOR:
                if view_rec[2] == 'True': # Count Active Customers
                    find_rec += 1
                if find_rec == int(view_index): # Customer Rec Located
                    break

            cust_id = view_rec[0] # Set Customer ID to return
        else:
            self.write_log('No Customers found, unable to process Account ' +
                           'actions at this time!', True) # print msgs
        return cust_id


main_obj = MainMenu()
cust_obj = Customer()
emp_obj = Employee()
acct_obj = Account()

main_obj.write_log('Calling get_menu_opt function',False)
menu_select = main_obj.get_menu_opt() # start with initial Main Menu
main_obj.write_log('Returned from get_menu_opt function',False)
print('')

while menu_select != 999: # 999 is value to Exit!
    if menu_select == 1: # 1 is value for Main Menu
        main_obj.write_log('Calling get_menu_opt function',False)
        menu_select = main_obj.get_menu_opt()
        main_obj.write_log('Returned from get_menu_opt function',False)

    elif menu_select == 11: # 11 is value for Customer Menu
        cust_obj.write_log('Calling get_menu_opt function',False)
        menu_select = cust_obj.get_menu_opt()
        cust_obj.write_log('Returned from get_menu_opt function',False)
    elif menu_select == 12: # 12 is value for Employee Menu
        emp_obj.write_log('Calling get_menu_opt function',False)
        menu_select = emp_obj.get_menu_opt()
        emp_obj.write_log('Returned from get_menu_opt function',False)
    elif menu_select == 13: # 13 is value for Account Menu
        acct_obj.write_log('Calling get_menu_opt function',False)
        menu_select = acct_obj.get_menu_opt()
        acct_obj.write_log('Returned from get_menu_opt function',False)

    elif menu_select == 111: # 111 is value for Customer View
        cust_obj.write_log('Calling view_object function',False)
        cust_obj.view_object()
        cust_obj.write_log('Returned from view_object function',False)
        menu_select = 11 # return to Customer Menu
    elif menu_select == 112: # 112 is value for Customer Add
        cust_obj.write_log('Calling add_object function',False)
        cust_obj.add_object()
        cust_obj.write_log('Returned from add_object function',False)
        menu_select = 11 # return to Customer Menu
    elif menu_select == 113: # 113 is value for Customer Modify
        cust_obj.write_log('Calling mod_object function',False)
        cust_obj.mod_object()
        cust_obj.write_log('Returned from mod_object function',False)
        menu_select = 11 # return to Customer Menu
    elif menu_select == 114: # 114 is value for Customer Delete
        cust_obj.write_log('Calling del_object function',False)
        cust_obj.del_object()
        cust_obj.write_log('Returned from del_object function',False)
        menu_select = 11 # return to Customer Menu

    elif menu_select == 121: # 121 is value for Employee View
        emp_obj.write_log('Calling view_object function',False)
        emp_obj.view_object()
        emp_obj.write_log('Returned from view_object function',False)
        menu_select = 12 # return to Employee Menu
    elif menu_select == 122: # 122 is value for Employee Add
        emp_obj.write_log('Calling add_object function',False)
        emp_obj.add_object()
        emp_obj.write_log('Returned from add_object function',False)
        menu_select = 12 # return to Employee Menu
    elif menu_select == 123: # 123 is value for Employee Modify
        emp_obj.write_log('Calling mod_object function',False)
        emp_obj.mod_object()
        emp_obj.write_log('Returned from mod_object function',False)
        menu_select = 12 # return to Employee Menu
    elif menu_select == 124: # 124 is value for Employee Delete
        emp_obj.write_log('Calling del_object function',False)
        emp_obj.del_object()
        emp_obj.write_log('Returned from del_object function',False)
        menu_select = 12 # return to Employee Menu

    elif menu_select == 131: # 131 is value for Account View
        acct_obj.write_log('Calling view_object function',False)
        acct_obj.view_object(acct_obj.sel_cust_id())
        acct_obj.write_log('Returned from view_object function',False)
        menu_select = 13 # return to Account Menu
    elif menu_select == 132: # 132 is value for Account Add
        acct_obj.write_log('Calling add_object function',False)
        acct_obj.add_object(acct_obj.sel_cust_id())
        acct_obj.write_log('Returned from add_object function',False)
        menu_select = 13 # return to Account Menu
    elif menu_select == 133: # 133 is value for Account Modify
        acct_obj.write_log('Calling mod_object function',False)
        acct_obj.mod_object(acct_obj.sel_cust_id())
        acct_obj.write_log('Returned from mod_object function',False)
        menu_select = 13 # return to Account Menu
    elif menu_select == 134: # 134 is value for Account Delete
        acct_obj.write_log('Calling del_object function',False)
        acct_obj.del_object(acct_obj.sel_cust_id())
        acct_obj.write_log('Returned from del_object function',False)
        menu_select = 13 # return to Account Menu

    else:
        self.write_log('IN ELSE STATEMENT - DEFAULTING TO MAIN MENU!!!', True)
        menu_select = 1 # 1 is value for Main Menu

    print('')

main_obj.write_log('Exiting the application clean!\n\n',False)
